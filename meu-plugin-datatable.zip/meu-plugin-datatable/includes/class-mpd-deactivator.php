<?php
class MPD_Deactivator {
    public static function deactivate() {
        // Nada por enquanto (não removemos tabela para evitar perda de dados)
    }
}